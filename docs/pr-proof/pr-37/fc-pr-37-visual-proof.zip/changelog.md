# PR #37 — Website premium de apresentação e contacto

## Changelog

- A FC Private Driver deixa de ser uma aplicação com contas, planos e pagamentos.
- Passa a ser um website estático premium de apresentação e contacto direto.
- Removida da experiência pública: autenticação, área de cliente/admin, planos Bronze/Prata/Ouro/Diamante, minutos, Stripe, Google Maps e reservas automáticas.
- Novo fluxo: conhecer serviços → escolher → contactar (WhatsApp/email) → orçamento e confirmação offline.
- Contactos oficiais: WhatsApp/telefone **933 239 595** · email **fcprivatedriver@gmail.com**.
- Formulário “Pedir serviço” com mensagem pré-preenchida para WhatsApp e mailto.
- Secção informativa de formas de pagamento (sem checkout).
- Página de Política de Privacidade com consentimento no formulário.
- Rotas antigas (`/login`, `/planos`, `/cliente`, `/admin`, `/pt/*`) redirecionam para o novo site.

## Novas funcionalidades

- Homepage premium mobile-first (“FC Private Driver” + CTAs Ver serviços / Falar no WhatsApp)
- Menu: Início, Serviços, Sobre, Contactos + Pedir serviço
- 10 categorias de serviço com “Pedir este serviço”
- Formulário de pedido (WhatsApp + email) sem base de dados
- Página Sobre e Política de Privacidade
- Formas de pagamento apenas informativas

## Serviços

1. Jovens  
2. Sénior  
3. Business  
4. Executivo  
5. Logístico  
6. Diversão & Lazer  
7. Pet  
8. Transfers  
9. Turismo & Passeios  
10. Motorista à Disposição  

## Verificação

- `npm run lint` — OK  
- `npx tsc --noEmit` — OK  
- `npm test` — 3/3 OK  
- `npm run build` — OK  

## Provas visuais

- `docs/pr-proof/pr-37/screenshots-phone/`
- `docs/pr-proof/pr-37/flow-phone.gif`
- `docs/pr-proof/pr-37/fc-pr-37-visual-proof.zip`
